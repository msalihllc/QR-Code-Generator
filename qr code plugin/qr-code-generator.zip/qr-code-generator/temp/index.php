<?php
// Güvenlik için boş index dosyası.